package com.james.dao.impl;

import org.springframework.stereotype.Component;
import com.james.dao.UserDao;
import java.util.List;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import cn.hutool.core.io.IoUtil;

@Component // 將類注入到Spring容器中
public class UserDaoImpl implements UserDao {
    @Override
    public List<String> findAll() {
        // 1. 加載.txt資料
        InputStream in = this.getClass().getClassLoader().getResourceAsStream("user.txt");
        ArrayList<String> lines = IoUtil.readLines(in, StandardCharsets.UTF_8, new ArrayList<>());
        return lines; 
    }
}
 