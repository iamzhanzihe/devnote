package com.james.controller;

import java.util.List;
import com.james.pojo.User;
import com.james.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class UserController {

    @Autowired
    private UserService userService;

    @RequestMapping("/list")
    public List<User> list() throws Exception{
        // 1. 調用UserService 查詢所有用戶
        List<User> userList = userService.findAll(); 

        // 2. 返回json
        return userList;
    }
}
   