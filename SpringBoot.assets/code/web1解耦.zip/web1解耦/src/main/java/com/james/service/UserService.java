package com.james.service;

import java.util.List;

import com.james.pojo.User;

public interface UserService {
    /**
     * 查詢所有用戶
     */
    public List<User> findAll();

}
