package com.james.dao;

import java.util.List;

public interface UserDao {

    /**
     * 查詢所有用戶
     */
    public List<String> findAll();
}
  